# Dehradun Estates & Developers — Complete Hosting Guide

## Your Website Deployment Roadmap

This guide will take you from zero to a fully live, professional website with custom domain, SSL, and email — all for free or under ₹500/year.

---

## STEP 1: Register Your Domain (5 minutes)

### Recommended Domain: `dehraduned.com`
**Why:** Short, memorable, maps to "DED" abbreviation, likely available.

### Where to Register:

**Option A — Namecheap (Recommended for beginners)**
1. Go to [namecheap.com](https://www.namecheap.com)
2. Search for `dehraduned.com`
3. Add to cart → Create account → Pay (~₹800-900/year)
4. Free WHOIS privacy included
5. Free DNS management included

**Option B — Hostinger (Cheapest)**
1. Go to [hostinger.com/domain-name-search](https://www.hostinger.com/domain-name-search)
2. Search → Purchase (~₹699/year for .com)

**Option C — GoDaddy**
1. Go to [godaddy.com](https://www.godaddy.com)
2. Search → Purchase (~₹999/year for .com)

### Also Consider Registering:
- `ded.xyz` (~₹150-200/year) — as a short, modern secondary domain
- `dehraduned.in` (~₹500/year) — for Indian market focus

---

## STEP 2: Create a GitHub Account (3 minutes)

1. Go to [github.com](https://github.com) → Sign Up
2. Create account with your email
3. Verify your email address
4. This is where your website code will live

---

## STEP 3: Upload Your Project to GitHub (5 minutes)

### Method A: GitHub Web Upload (Easiest — No coding needed)
1. Go to [github.com/new](https://github.com/new)
2. Repository name: `ded-website`
3. Select **Private**
4. Click **Create repository**
5. Click **"uploading an existing file"** link
6. **Unzip** the `ded-website-vercel-ready.zip` file on your computer
7. Drag ALL files from inside the `ded-website` folder into the upload area
8. Make sure the folder structure is:
   - `app/` folder (containing `page.js`, `layout.js`, `DehradunEstates.jsx`)
   - `public/` folder (containing `robots.txt`, `sitemap.xml`)
   - `package.json`
   - `next.config.js`
   - `vercel.json`
   - `.gitignore`
9. Click **Commit changes**

### Method B: Using Git (If you're comfortable with terminal)
```bash
cd ded-website
git init
git add .
git commit -m "Initial commit - Dehradun Estates website"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/ded-website.git
git push -u origin main
```

---

## STEP 4: Deploy on Vercel (3 minutes)

Vercel is the best free hosting for your website — it's made by the creators of Next.js.

1. Go to [vercel.com](https://vercel.com)
2. Click **"Sign Up"** → Choose **"Continue with GitHub"**
3. Authorize Vercel to access your GitHub
4. Click **"Add New..." → "Project"**
5. You'll see your `ded-website` repo → Click **"Import"**
6. Settings will auto-detect Next.js:
   - Framework Preset: **Next.js** ✓
   - Root Directory: `./` ✓
   - Build Command: `next build` ✓
7. Click **"Deploy"**
8. Wait 1-2 minutes for build to complete
9. Your site is now LIVE at `https://ded-website.vercel.app` 🎉

---

## STEP 5: Connect Your Custom Domain (5 minutes)

1. In Vercel dashboard → Go to your project → **Settings** → **Domains**
2. Type `dehraduned.com` → Click **Add**
3. Vercel will show you DNS records to add. You'll see something like:
   - Type: `A`, Name: `@`, Value: `76.76.21.21`
   - Type: `CNAME`, Name: `www`, Value: `cname.vercel-dns.com`

### Add DNS Records at Your Domain Registrar:

**If using Namecheap:**
1. Log into Namecheap → Domain List → Manage → Advanced DNS
2. Delete any existing A records and CNAME for `www`
3. Add new records:
   - Type: `A Record`, Host: `@`, Value: `76.76.21.21`, TTL: Auto
   - Type: `CNAME Record`, Host: `www`, Value: `cname.vercel-dns.com`, TTL: Auto
4. Save changes

**If using Hostinger/GoDaddy:** Similar process in their DNS management panel.

4. Back in Vercel, click **Verify** — it may take 5-30 minutes for DNS to propagate
5. Vercel automatically provisions a **free SSL certificate** (https://) 🔒

Your site is now live at **https://dehraduned.com** 🎉

---

## STEP 6: Set Up Professional Email (10 minutes)

### Option A: Zoho Mail (FREE — Up to 5 users)
Best free option for business email.

1. Go to [zoho.com/mail](https://www.zoho.com/mail/)
2. Click **"Sign Up Free"** → Choose **"Mail Only"** plan
3. Enter your domain: `dehraduned.com`
4. Create your admin email: `info@dehraduned.com`
5. Verify domain by adding a TXT record:
   - Go to Namecheap DNS → Add TXT record as shown by Zoho
6. Add MX records (Zoho will tell you exactly what):
   - `mx.zoho.in` (Priority: 10)
   - `mx2.zoho.in` (Priority: 20)
   - `mx3.zoho.in` (Priority: 50)
7. Create email addresses:
   - `info@dehraduned.com` — General inquiries
   - `sales@dehraduned.com` — Sales team
   - `support@dehraduned.com` — Customer support

### Option B: Google Workspace (₹125/month per user)
If you want Gmail interface with your domain:
1. Go to [workspace.google.com](https://workspace.google.com)
2. Start trial → Add your domain → Set up DNS records
3. You get `yourname@dehraduned.com` with full Gmail features

---

## STEP 7: Google Search Console & Analytics (10 minutes)

### Google Search Console (Get found on Google):
1. Go to [search.google.com/search-console](https://search.google.com/search-console)
2. Add property → Enter `dehraduned.com`
3. Verify via DNS → Add the TXT record Namecheap
4. Submit your sitemap: `https://dehraduned.com/sitemap.xml`

### Google Analytics (Track visitors):
1. Go to [analytics.google.com](https://analytics.google.com)
2. Create account → Create property for `dehraduned.com`
3. Get your tracking ID (G-XXXXXXXXXX)
4. Add to your website's `layout.js` file (I can help with this)

### Google Business Profile:
1. Go to [business.google.com](https://business.google.com)
2. Create profile for "Dehradun Estates & Developers"
3. Add address, phone (9927715097), website (dehraduned.com)
4. This helps you appear in Google Maps and local searches

---

## COST SUMMARY

| Item | Cost | Frequency |
|------|------|-----------|
| Domain (dehraduned.com) | ₹800-900 | Per year |
| Vercel Hosting | FREE | Forever (hobby plan) |
| SSL Certificate | FREE | Auto-renewed by Vercel |
| Zoho Email (5 users) | FREE | Forever |
| Google Search Console | FREE | Forever |
| Google Analytics | FREE | Forever |
| **TOTAL** | **~₹900/year** | |

---

## FUTURE UPGRADES

When your business grows, consider:

- **Vercel Pro** ($20/mo) — For more bandwidth and team features
- **Google Workspace** (₹125/user/mo) — Professional Gmail
- **Cloudflare** (Free) — Extra speed and security
- **Custom backend** — Add Node.js API routes in the `app/api/` folder for contact forms, lead management, etc.
- **CMS Integration** — Connect Sanity or Strapi for easy content updates
- **WhatsApp Business API** — For automated customer chat

---

## NEED HELP?

If you get stuck at any step, come back and ask me! I can help you:
- Debug deployment issues
- Add Google Analytics code
- Set up a contact form that actually sends emails
- Create API routes for lead capture
- Add WhatsApp chat widget
- Optimize for Google SEO
- Set up Google Ads campaigns

**Your website is built. Now let's get it live! Start with Step 1 → Register your domain.**
